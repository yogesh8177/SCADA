<?php 

define('DBHOST', 'localhost');
define('DBNAME', 'scada');
define('DBUSER', 'root');
define('DBPASSWORD', '');

?>